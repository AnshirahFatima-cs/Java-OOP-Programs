package foodorderingsystem;

//inheritance using extend
public class Shawarma extends FoodItem {
    //aattributes
    private String meatType;
    private boolean withGarlic;
    //constructor
    public Shawarma(String itemName, double price, String meatType, boolean withGarlic) {
        super(itemName, price);
        this.meatType = meatType;
        this.withGarlic = withGarlic;
    }
    //overring method
    @Override
    public String getCategory() { return "Shawarma"; }
    
    @Override
    public String getDescription() {
        return meatType + " Shawarma " + (withGarlic ? "with garlic sauce" : "without garlic");
    }
    
    @Override
    public String prepareItem() {
        return "Preparing " + getItemName() + ": Slicing " + meatType + 
               " from rotisserie, wrapping in bread with veggies and " + 
               (withGarlic ? "garlic sauce." : "tahini sauce.");
    }
    //methods to get types of meal
    public String getMeatType() { return meatType; }
    public boolean isWithGarlic() { return withGarlic; }
}
