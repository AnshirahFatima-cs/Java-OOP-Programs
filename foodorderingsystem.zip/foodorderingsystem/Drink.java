package foodorderingsystem;

public class Drink extends FoodItem {
    
    private boolean isHot;
    private String size;
    
    public Drink(String itemName, double price, boolean isHot, String size) {
        super(itemName, price);
        this.isHot = isHot;
        this.size = size;
    }
    
    @Override
    public String getCategory() { return "Drink"; }
    
    @Override
    public String getDescription() {
        return (isHot ? "Hot" : "Cold") + " " + size + " " + getItemName();
    }
    
    @Override
    public String prepareItem() {
        return "Preparing " + getItemName() + ": " + 
               (isHot ? "Heating and brewing " : "Chilling and pouring ") + 
               size + " serving.";
    }
    
    public boolean isHot() { return isHot; }
    public String getSize() { return size; }
}
