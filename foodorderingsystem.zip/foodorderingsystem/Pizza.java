package foodorderingsystem;

// INHERITANCE — Pizza extends FoodItem
public class Pizza extends FoodItem {
    //attributes
    private String size;
    private String crust;
    //constructor
    public Pizza(String itemName, double price, String size, String crust) {
        super(itemName, price);
        this.size = size;
        this.crust = crust;
    }
    
    // POLYMORPHISM — Override abstract methods
    @Override
    public String getCategory() {
        return "Pizza";
    }
    
    @Override
    public String getDescription() {
        return size + " size " + getItemName() + " with " + crust + " crust";
    }
    
    @Override
    public String prepareItem() {
        return "Preparing " + getItemName() + ": Spreading sauce, adding toppings, baking at 400°F for 15 minutes.";
    }
    
    public String getSize() { return size; }
    public String getCrust() { return crust; }
}
