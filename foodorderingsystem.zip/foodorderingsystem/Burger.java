package foodorderingsystem;

// INHERITANCE — Burger extends FoodItem
public class Burger extends FoodItem {
    
    private boolean isSpicy;
    private String pattyType;
    
    public Burger(String itemName, double price, boolean isSpicy, String pattyType) {
        super(itemName, price);
        this.isSpicy = isSpicy;
        this.pattyType = pattyType;
    }
    
    @Override
    public String getCategory() { return "Burger"; }
    
    @Override
    public String getDescription() {
        return (isSpicy ? "Spicy " : "Regular ") + pattyType + " " + getItemName();
    }
    
    @Override
    public String prepareItem() {
        return "Preparing " + getItemName() + ": Grilling " + pattyType + 
               " patty, toasting bun, adding " + (isSpicy ? "spicy" : "regular") + " sauce.";
    }
    
    public boolean isSpicy() { return isSpicy; }
    public String getPattyType() { return pattyType; }
}
