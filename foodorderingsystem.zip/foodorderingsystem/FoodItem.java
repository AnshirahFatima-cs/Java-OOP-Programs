package foodorderingsystem;

// ABSTRACTION — Abstract base class
public abstract class FoodItem {
    
    // ENCAPSULATION — private attributes
    private String itemName;
    private double price;
    private int quantity;
    private boolean isAvailable;
    
    // Constructor
    public FoodItem(String itemName, double price) {
        this.itemName = itemName;
        this.price = price;
        this.quantity = 1;
        this.isAvailable = true;
    }
    
    // Abstract methods — subclasses must implement
    public abstract String getCategory();
    public abstract String getDescription();
    public abstract String prepareItem();
    
    // Concrete method — inherited by all subclasses
    public double calculateTotal() {
        return price * quantity;
    }
    
    // Overloaded calculateTotal — POLYMORPHISM
    public double calculateTotal(int qty) {
        return price * qty;
    }
    
    // Overloaded calculateTotal with discount
    public double calculateTotal(int qty, double discountPercent) {
        double total = price * qty;
        return total - (total * discountPercent / 100);
    }
    
    // ENCAPSULATION — Getters and Setters
    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }
    //method to get price
    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price > 0) this.price = price;
    }
    //methods to get quantity
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) {
        if (quantity > 0) this.quantity = quantity;
    }
    //method to check if item is available or not
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { this.isAvailable = available; }
    //used polymorphism through overriding
    @Override
    public String toString() {
        return itemName + " - Rs." + price;
    }
}
