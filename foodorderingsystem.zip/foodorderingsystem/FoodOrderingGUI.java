package foodorderingsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class FoodOrderingGUI extends JFrame {

    // Colors
    private final Color PRIMARY = new Color(255, 87, 34);
    private final Color SECONDARY = new Color(255, 152, 0);
    private final Color DARK = new Color(33, 33, 33);
    private final Color LIGHT = new Color(250, 250, 250);
    private final Color GREEN = new Color(76, 175, 80);
    private final Color WHITE = Color.WHITE;

    // Data
    private Order currentOrder;
    private ArrayList<FoodItem> menuItems;

    // GUI Components
    private JTextField txtCustomerName;
    private JComboBox<String> cmbCategory;
    private JList<String> lstMenu;
    private DefaultListModel<String> menuModel;
    private JTable tblCart;
    private DefaultTableModel cartModel;
    private JTextArea txtReceipt;
    private JLabel lblTotal;
    private JLabel lblStatus;
    private JSpinner spinQuantity;
    private JTextArea txtItemDesc;

    public FoodOrderingGUI() {
        initializeMenu();
        initializeGUI();
    }

    private void initializeMenu() {
        menuItems = new ArrayList<>();

        // Pizzas
        menuItems.add(new Pizza("Margherita Pizza", 550, "Medium", "Thin"));
        menuItems.add(new Pizza("Pepperoni Pizza", 650, "Medium", "Thick"));
        menuItems.add(new Pizza("BBQ Chicken Pizza", 700, "Large", "Stuffed"));
        menuItems.add(new Pizza("Veggie Supreme Pizza", 500, "Medium", "Thin"));

        // Burgers
        menuItems.add(new Burger("Classic Beef Burger", 350, false, "Beef"));
        menuItems.add(new Burger("Spicy Zinger Burger", 400, true, "Chicken"));
        menuItems.add(new Burger("Double Smash Burger", 500, false, "Beef"));
        menuItems.add(new Burger("Crispy Chicken Burger", 380, false, "Chicken"));

        // Shawarma
        menuItems.add(new Shawarma("Chicken Shawarma", 280, "Chicken", true));
        menuItems.add(new Shawarma("Beef Shawarma", 320, "Beef", true));
        menuItems.add(new Shawarma("Mix Shawarma", 350, "Mix", false));

        // Fries
        menuItems.add(new Fries("Regular Fries", 150, "Regular", false));
        menuItems.add(new Fries("Large Fries", 200, "Large", false));
        menuItems.add(new Fries("Masala Fries", 180, "Regular", true));
        menuItems.add(new Fries("Cheese Fries", 250, "Large", false));

        // Drinks
        menuItems.add(new Drink("Coca Cola", 100, false, "Regular"));
        menuItems.add(new Drink("Mango Juice", 120, false, "Large"));
        menuItems.add(new Drink("Hot Tea", 80, true, "Regular"));
        menuItems.add(new Drink("Cold Coffee", 200, false, "Large"));
        menuItems.add(new Drink("Mineral Water", 60, false, "Regular"));
    }

    private void initializeGUI() {
        setTitle("🍔 Foodie Express - Online Food Ordering System");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));
        getContentPane().setBackground(DARK);

        // Build all panels
        add(buildHeaderPanel(), BorderLayout.NORTH);
        add(buildMainPanel(), BorderLayout.CENTER);
        add(buildStatusPanel(), BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ===================== HEADER =====================
    private JPanel buildHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel title = new JLabel("🍔  FOODIE EXPRESS");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(WHITE);

        JLabel subtitle = new JLabel("Fast Food | Pizza | Shawarma | Burgers");
        subtitle.setFont(new Font("Arial", Font.ITALIC, 13));
        subtitle.setForeground(new Color(255, 220, 200));

        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setBackground(PRIMARY);
        titlePanel.add(title);
        titlePanel.add(subtitle);

        // Customer name panel
        JPanel customerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        customerPanel.setBackground(PRIMARY);

        JLabel lblCust = new JLabel("Customer Name: ");
        lblCust.setForeground(WHITE);
        lblCust.setFont(new Font("Arial", Font.BOLD, 13));

        txtCustomerName = new JTextField("Enter your name", 18);
        txtCustomerName.setFont(new Font("Arial", Font.PLAIN, 13));
        txtCustomerName.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (txtCustomerName.getText().equals("Enter your name"))
                    txtCustomerName.setText("");
            }
        });

        JButton btnStart = createButton("Start Order", GREEN);
        btnStart.addActionListener(e -> startOrder());

        customerPanel.add(lblCust);
        customerPanel.add(txtCustomerName);
        customerPanel.add(btnStart);

        header.add(titlePanel, BorderLayout.WEST);
        header.add(customerPanel, BorderLayout.EAST);

        return header;
    }

    // ===================== MAIN PANEL =====================
    private JPanel buildMainPanel() {
        JPanel main = new JPanel(new GridLayout(1, 3, 5, 5));
        main.setBackground(DARK);
        main.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        main.add(buildMenuPanel());
        main.add(buildCartPanel());
        main.add(buildReceiptPanel());

        return main;
    }

    // ===================== MENU PANEL =====================
    private JPanel buildMenuPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(new Color(45, 45, 45));
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(PRIMARY, 2), 
            "  📋 MENU  ", 0, 0, 
            new Font("Arial", Font.BOLD, 14), PRIMARY));

        // Category filter
        JPanel filterPanel = new JPanel(new FlowLayout());
        filterPanel.setBackground(new Color(45, 45, 45));

        JLabel lblCat = new JLabel("Category: ");
        lblCat.setForeground(WHITE);
        lblCat.setFont(new Font("Arial", Font.BOLD, 12));

        String[] categories = {"All", "Pizza", "Burger", "Shawarma", "Fries", "Drink"};
        cmbCategory = new JComboBox<>(categories);
        cmbCategory.setFont(new Font("Arial", Font.PLAIN, 12));
        cmbCategory.setBackground(new Color(60, 60, 60));
        cmbCategory.setForeground(WHITE);
        cmbCategory.addActionListener(e -> filterMenu());

        filterPanel.add(lblCat);
        filterPanel.add(cmbCategory);

        // Menu list
        menuModel = new DefaultListModel<>();
        lstMenu = new JList<>(menuModel);
        lstMenu.setBackground(new Color(55, 55, 55));
        lstMenu.setForeground(WHITE);
        lstMenu.setFont(new Font("Arial", Font.PLAIN, 13));
        lstMenu.setSelectionBackground(PRIMARY);
        lstMenu.setSelectionForeground(WHITE);
        lstMenu.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        lstMenu.addListSelectionListener(e -> showItemDescription());

        loadMenuItems("All");

        JScrollPane scrollMenu = new JScrollPane(lstMenu);
        scrollMenu.setBorder(BorderFactory.createEmptyBorder());

        // Item description
        txtItemDesc = new JTextArea(3, 20);
        txtItemDesc.setBackground(new Color(40, 40, 40));
        txtItemDesc.setForeground(new Color(200, 200, 200));
        txtItemDesc.setFont(new Font("Arial", Font.ITALIC, 11));
        txtItemDesc.setEditable(false);
        txtItemDesc.setLineWrap(true);
        txtItemDesc.setWrapStyleWord(true);
        txtItemDesc.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Quantity and Add button
        JPanel addPanel = new JPanel(new FlowLayout());
        addPanel.setBackground(new Color(45, 45, 45));

        JLabel lblQty = new JLabel("Qty: ");
        lblQty.setForeground(WHITE);
        lblQty.setFont(new Font("Arial", Font.BOLD, 12));

        spinQuantity = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        spinQuantity.setPreferredSize(new Dimension(60, 28));

        JButton btnAdd = createButton("➕ Add to Cart", GREEN);
        btnAdd.addActionListener(e -> addToCart());

        addPanel.add(lblQty);
        addPanel.add(spinQuantity);
        addPanel.add(btnAdd);

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(scrollMenu, BorderLayout.CENTER);
        panel.add(new JScrollPane(txtItemDesc), BorderLayout.SOUTH);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(45, 45, 45));
        bottomPanel.add(new JScrollPane(txtItemDesc), BorderLayout.CENTER);
        bottomPanel.add(addPanel, BorderLayout.SOUTH);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // ===================== CART PANEL =====================
    private JPanel buildCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(new Color(45, 45, 45));
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(SECONDARY, 2),
            "  🛒 YOUR CART  ", 0, 0,
            new Font("Arial", Font.BOLD, 14), SECONDARY));

        // Cart table
        String[] columns = {"Item", "Category", "Qty", "Price", "Total"};
        cartModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        tblCart = new JTable(cartModel);
        tblCart.setBackground(new Color(55, 55, 55));
        tblCart.setForeground(WHITE);
        tblCart.setFont(new Font("Arial", Font.PLAIN, 12));
        tblCart.setRowHeight(28);
        tblCart.setGridColor(new Color(80, 80, 80));
        tblCart.getTableHeader().setBackground(SECONDARY);
        tblCart.getTableHeader().setForeground(WHITE);
        tblCart.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tblCart.setSelectionBackground(new Color(255, 120, 50));

        // Column widths
        tblCart.getColumnModel().getColumn(0).setPreferredWidth(120);
        tblCart.getColumnModel().getColumn(1).setPreferredWidth(70);
        tblCart.getColumnModel().getColumn(2).setPreferredWidth(40);
        tblCart.getColumnModel().getColumn(3).setPreferredWidth(60);
        tblCart.getColumnModel().getColumn(4).setPreferredWidth(65);

        JScrollPane scrollCart = new JScrollPane(tblCart);
        scrollCart.setBorder(BorderFactory.createEmptyBorder());
        scrollCart.getViewport().setBackground(new Color(55, 55, 55));

        // Total label
        lblTotal = new JLabel("Grand Total: Rs. 0");
        lblTotal.setForeground(SECONDARY);
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
        lblTotal.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        lblTotal.setHorizontalAlignment(SwingConstants.RIGHT);

        // Cart buttons
        JPanel btnPanel = new JPanel(new GridLayout(1, 3, 5, 5));
        btnPanel.setBackground(new Color(45, 45, 45));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JButton btnRemove = createButton("🗑 Remove", new Color(244, 67, 54));
        btnRemove.addActionListener(e -> removeFromCart());

        JButton btnClear = createButton("🔄 Clear All", new Color(96, 125, 139));
        btnClear.addActionListener(e -> clearCart());

        JButton btnOrder = createButton("✅ Place Order", PRIMARY);
        btnOrder.addActionListener(e -> placeOrder());

        btnPanel.add(btnRemove);
        btnPanel.add(btnClear);
        btnPanel.add(btnOrder);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(45, 45, 45));
        bottomPanel.add(lblTotal, BorderLayout.CENTER);
        bottomPanel.add(btnPanel, BorderLayout.SOUTH);

        panel.add(scrollCart, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // ===================== RECEIPT PANEL =====================
    private JPanel buildReceiptPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(new Color(45, 45, 45));
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(GREEN, 2),
            "  🧾 ORDER RECEIPT  ", 0, 0,
            new Font("Arial", Font.BOLD, 14), GREEN));

        txtReceipt = new JTextArea();
        txtReceipt.setBackground(new Color(20, 20, 20));
        txtReceipt.setForeground(new Color(0, 255, 100));
        txtReceipt.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtReceipt.setEditable(false);
        txtReceipt.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtReceipt.setText("\n\n\n   Please enter your name and\n" +
                          "   click 'Start Order' to begin!\n\n\n" +
                          "   Then add items to your cart\n" +
                          "   and click 'Place Order'\n" +
                          "   to see your receipt here.");

        JScrollPane scrollReceipt = new JScrollPane(txtReceipt);
        scrollReceipt.setBorder(BorderFactory.createEmptyBorder());

        JButton btnNewOrder = createButton("🆕 New Order", new Color(33, 150, 243));
        btnNewOrder.addActionListener(e -> newOrder());
        btnNewOrder.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(scrollReceipt, BorderLayout.CENTER);
        panel.add(btnNewOrder, BorderLayout.SOUTH);

        return panel;
    }

    // ===================== STATUS BAR =====================
    private JPanel buildStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(30, 30, 30));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        lblStatus = new JLabel("👋 Welcome to Foodie Express! Please enter your name to start ordering.");
        lblStatus.setForeground(new Color(180, 180, 180));
        lblStatus.setFont(new Font("Arial", Font.ITALIC, 12));

        panel.add(lblStatus, BorderLayout.WEST);

        JLabel lblVersion = new JLabel("OOPT Java Project — All 4 OOP Pillars Applied");
        lblVersion.setForeground(new Color(100, 100, 100));
        lblVersion.setFont(new Font("Arial", Font.PLAIN, 11));

        panel.add(lblVersion, BorderLayout.EAST);

        return panel;
    }

    // ===================== HELPER METHODS =====================
    private JButton createButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(color);
            }
        });
        return btn;
    }

    private void loadMenuItems(String category) {
        menuModel.clear();
        for (FoodItem item : menuItems) {
            if (category.equals("All") || item.getCategory().equals(category)) {
                menuModel.addElement(item.getItemName() + "  —  Rs." + (int) item.getPrice());
            }
        }
    }

    private void filterMenu() {
        String selected = (String) cmbCategory.getSelectedItem();
        loadMenuItems(selected);
        txtItemDesc.setText("");
    }

    private void showItemDescription() {
        int index = lstMenu.getSelectedIndex();
        if (index >= 0) {
            String selectedCategory = (String) cmbCategory.getSelectedItem();
            int actualIndex = getActualIndex(index, selectedCategory);
            if (actualIndex >= 0) {
                FoodItem item = menuItems.get(actualIndex);
                txtItemDesc.setText("📝 " + item.getDescription() + "\n\n👨‍🍳 " + item.prepareItem());
            }
        }
    }

    private int getActualIndex(int listIndex, String category) {
        int count = 0;
        for (int i = 0; i < menuItems.size(); i++) {
            if (category.equals("All") || menuItems.get(i).getCategory().equals(category)) {
                if (count == listIndex) return i;
                count++;
            }
        }
        return -1;
    }

    private void startOrder() {
        String name = txtCustomerName.getText().trim();
        if (name.isEmpty() || name.equals("Enter your name")) {
            JOptionPane.showMessageDialog(this, "Please enter your name first!", 
                "Name Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        currentOrder = new Order(name);
        lblStatus.setText("✅ Order started for: " + name + " | Add items from the menu!");
        txtReceipt.setText("\n\n  Order started for: " + name + "\n\n  Add items to cart and\n  click Place Order!");
        updateTotal();
    }

    private void addToCart() {
        if (currentOrder == null) {
            JOptionPane.showMessageDialog(this, "Please start an order first!", 
                "No Order", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int index = lstMenu.getSelectedIndex();
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item from the menu!", 
                "No Item Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String selectedCategory = (String) cmbCategory.getSelectedItem();
        int actualIndex = getActualIndex(index, selectedCategory);

        if (actualIndex >= 0) {
            FoodItem item = menuItems.get(actualIndex);
            int qty = (int) spinQuantity.getValue();

            // Create new instance with selected quantity
            FoodItem orderItem = createItemCopy(item, qty);

            currentOrder.addItem(orderItem);

            // Add to cart table
            cartModel.addRow(new Object[]{
                orderItem.getItemName(),
                orderItem.getCategory(),
                qty,
                "Rs." + (int) orderItem.getPrice(),
                "Rs." + (int) orderItem.calculateTotal()
            });

            updateTotal();
            lblStatus.setText("✅ Added: " + orderItem.getItemName() + " x" + qty + " to cart!");
        }
    }

    private FoodItem createItemCopy(FoodItem original, int qty) {
        FoodItem copy;
        if (original instanceof Pizza) {
            Pizza p = (Pizza) original;
            copy = new Pizza(p.getItemName(), p.getPrice(), p.getSize(), p.getCrust());
        } else if (original instanceof Burger) {
            Burger b = (Burger) original;
            copy = new Burger(b.getItemName(), b.getPrice(), b.isSpicy(), b.getPattyType());
        } else if (original instanceof Shawarma) {
            Shawarma s = (Shawarma) original;
            copy = new Shawarma(s.getItemName(), s.getPrice(), s.getMeatType(), s.isWithGarlic());
        } else if (original instanceof Fries) {
            Fries f = (Fries) original;
            copy = new Fries(f.getItemName(), f.getPrice(), f.getSize(), false);
        } else {
            Drink d = (Drink) original;
            copy = new Drink(d.getItemName(), d.getPrice(), d.isHot(), d.getSize());
        }
        copy.setQuantity(qty);
        return copy;
    }

    private void removeFromCart() {
        int row = tblCart.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item to remove!", 
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String itemName = (String) cartModel.getValueAt(row, 0);
        currentOrder.removeItem(row);
        cartModel.removeRow(row);
        updateTotal();
        lblStatus.setText("🗑 Removed: " + itemName + " from cart.");
    }

    private void clearCart() {
        if (currentOrder == null || currentOrder.getCartSize() == 0) return;
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Clear all items from cart?", "Confirm Clear", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            currentOrder.clearCart();
            cartModel.setRowCount(0);
            updateTotal();
            lblStatus.setText("🔄 Cart cleared.");
        }
    }

    private void placeOrder() {
        if (currentOrder == null || currentOrder.getCartSize() == 0) {
            JOptionPane.showMessageDialog(this, "Your cart is empty! Add items first.", 
                "Empty Cart", JOptionPane.WARNING_MESSAGE);
            return;
        }

        currentOrder.setOrderStatus("Confirmed ✅");
        txtReceipt.setText(currentOrder.generateReceipt());
        lblStatus.setText("🎉 Order #" + currentOrder.getOrderNumber() + 
                         " placed successfully for " + currentOrder.getCustomerName() + "!");

        JOptionPane.showMessageDialog(this,
            "Order placed successfully!\nThank you, " + currentOrder.getCustomerName() + "!",
            "Order Confirmed! 🎉", JOptionPane.INFORMATION_MESSAGE);
    }

    private void newOrder() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Start a new order? Current order will be cleared.",
            "New Order", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            currentOrder = null;
            cartModel.setRowCount(0);
            txtCustomerName.setText("Enter your name");
            txtReceipt.setText("\n\n\n   New order ready!\n   Enter your name\n   and click Start Order.");
            lblTotal.setText("Grand Total: Rs. 0");
            lblStatus.setText("👋 Welcome back! Enter your name to start a new order.");
        }
    }

    private void updateTotal() {
        if (currentOrder != null) {
            double total = currentOrder.calculateGrandTotal();
            lblTotal.setText("Grand Total (incl. 10% tax): Rs. " + String.format("%.0f", total));
        }
    }

    // ===================== MAIN METHOD =====================
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // use default
        }

        SwingUtilities.invokeLater(() -> new FoodOrderingGUI());
    }
}
