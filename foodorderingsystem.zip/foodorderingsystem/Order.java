package foodorderingsystem;

import java.util.ArrayList;

public class Order {
    //array list
    
    private ArrayList<FoodItem> cartItems;
    private String customerName;
    private String orderStatus;
    private int orderNumber;
    private static int orderCount = 0;
    
    //constructor
    public Order(String customerName) {
        this.customerName = customerName;
        this.cartItems = new ArrayList<>();
        this.orderStatus = "Pending";
        orderCount++;
        this.orderNumber = orderCount;
    }
    //method to add item in card
    public void addItem(FoodItem item) {
        cartItems.add(item);
    }
    //remove item
    public void removeItem(int index) {
        if (index >= 0 && index < cartItems.size()) {
            cartItems.remove(index);
        }
    }
    //clear cart if want to
    public void clearCart() {
        cartItems.clear();
    }
    //calculating total bill
    public double calculateSubTotal() {
        double total = 0;
        for (FoodItem item : cartItems) {
            total += item.calculateTotal();
        }
        return total;
    }
    //method to calculate tax
    public double calculateTax() {
        return calculateSubTotal() * 0.10; // 10% tax
    }
    //grand total bill
    public double calculateGrandTotal() {
        return calculateSubTotal() + calculateTax();
    }
    //method to generate final receipt
    public String generateReceipt() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("========================================\n");
        receipt.append("       FOODIE EXPRESS - ORDER RECEIPT   \n");
        receipt.append("========================================\n");
        receipt.append("Order No: #").append(orderNumber).append("\n");
        receipt.append("Customer: ").append(customerName).append("\n");
        receipt.append("----------------------------------------\n");
        receipt.append(String.format("%-20s %5s %10s\n", "Item", "Qty", "Price"));
        receipt.append("----------------------------------------\n");
        //for loop for continous iteration
        for (FoodItem item : cartItems) {
            receipt.append(String.format("%-20s %5d %10s\n",
                item.getItemName(),
                item.getQuantity(),
                "Rs." + String.format("%.0f", item.calculateTotal())));
        }
        
        receipt.append("----------------------------------------\n");
        receipt.append(String.format("%-25s %10s\n", "Subtotal:", "Rs." + String.format("%.0f", calculateSubTotal())));
        receipt.append(String.format("%-25s %10s\n", "Tax (10%):", "Rs." + String.format("%.0f", calculateTax())));
        receipt.append("========================================\n");
        receipt.append(String.format("%-25s %10s\n", "GRAND TOTAL:", "Rs." + String.format("%.0f", calculateGrandTotal())));
        receipt.append("========================================\n");
        receipt.append("Status: ").append(orderStatus).append("\n");
        receipt.append("  Thank you for ordering with us!  \n");
        receipt.append("========================================\n");
        
        return receipt.toString();
    }
    
    // Getters
    public ArrayList<FoodItem> getCartItems() { return cartItems; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String name) { this.customerName = name; }
    public String getOrderStatus() { return orderStatus; }
    public void setOrderStatus(String status) { this.orderStatus = status; }
    public int getOrderNumber() { return orderNumber; }
    public int getCartSize() { return cartItems.size(); }
}
