package foodorderingsystem;

public class Fries extends FoodItem {
    //attributes
    private String size;
    private boolean extraSalt;
    //constructor
    public Fries(String itemName, double price, String size, boolean extraSalt) {
        super(itemName, price);
        this.size = size;
        this.extraSalt = extraSalt;
    }
    //implementing polymorphism through override
    @Override
    public String getCategory() { return "Fries"; }
    
    @Override
    public String getDescription() {
        return size + " " + getItemName() + (extraSalt ? " with extra salt" : "");
    }
    
    @Override
    public String prepareItem() {
        return "Preparing " + getItemName() + ": Deep frying " + size + 
               " portion at 180°C for 4 minutes" + (extraSalt ? ", adding extra salt." : ".");
    }
    //getting size method
    public String getSize() { return size; }
}
