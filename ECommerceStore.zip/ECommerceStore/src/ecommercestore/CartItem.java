package ecommercestore;

/**
 * CartItem class - COMPOSITION (Cart HAS-A CartItem, CartItem HAS-A Product)
 */
public class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public double getItemTotal() { return product.getFinalPrice(quantity); }
    public double getItemTotalWithCoupon(double coupon) { return product.getFinalPrice(quantity, coupon); }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int qty) { if (qty > 0) this.quantity = qty; }

    @Override
    public String toString() {
        return product.getProductName() + " x" + quantity + " = Rs." + (int) getItemTotal();
    }
}
