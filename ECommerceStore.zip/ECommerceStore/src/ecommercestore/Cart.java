package ecommercestore;

import java.util.ArrayList;

public class Cart {

    private ArrayList<Product> cartItems;
    private String customerName;
    private String customerEmail;
    private static int orderCount = 0;
    private int orderNumber;
    private String orderStatus;

    public Cart(String customerName, String customerEmail) {
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.cartItems = new ArrayList<>();
        this.orderStatus = "Pending";
        orderCount++;
        this.orderNumber = orderCount;
    }

    public void addItem(Product item) { cartItems.add(item); }

    public void removeItem(int index) {
        if (index >= 0 && index < cartItems.size())
            cartItems.remove(index);
    }

    public void clearCart() { cartItems.clear(); }

    public double calculateSubTotal() {
        double total = 0;
        for (Product p : cartItems)
            total += p.calculateTotal(p.getQuantity());
        return total;
    }

    public double calculateShipping() {
        double sub = calculateSubTotal();
        if (sub >= 5000) return 0;
        return 200;
    }

    public double calculateTax() {
        return calculateSubTotal() * 0.05;
    }

    public double calculateGrandTotal() {
        return calculateSubTotal() + calculateShipping() + calculateTax();
    }

    public double calculateSavings() {
        double original = 0;
        for (Product p : cartItems)
            original += p.getPrice() * p.getQuantity();
        return original - calculateSubTotal();
    }

    public String generateReceipt() {
        StringBuilder r = new StringBuilder();
        r.append("============================================\n");
        r.append("         SHOPZONE — ORDER RECEIPT           \n");
        r.append("============================================\n");
        r.append("Order No  : #").append(orderNumber).append("\n");
        r.append("Customer  : ").append(customerName).append("\n");
        r.append("Email     : ").append(customerEmail).append("\n");
        r.append("--------------------------------------------\n");
        r.append(String.format("%-22s %4s %10s\n", "Product", "Qty", "Amount"));
        r.append("--------------------------------------------\n");

        for (Product p : cartItems) {
            r.append(String.format("%-22s %4d %10s\n",
                p.getProductName().length() > 20
                    ? p.getProductName().substring(0, 20)
                    : p.getProductName(),
                p.getQuantity(),
                "Rs." + (int) p.calculateTotal(p.getQuantity())));
        }

        r.append("--------------------------------------------\n");
        r.append(String.format("%-27s %9s\n", "Subtotal:", "Rs." + (int) calculateSubTotal()));
        r.append(String.format("%-27s %9s\n", "You Saved:", "Rs." + (int) calculateSavings()));
        r.append(String.format("%-27s %9s\n", "Shipping:",
            calculateShipping() == 0 ? "FREE" : "Rs." + (int) calculateShipping()));
        r.append(String.format("%-27s %9s\n", "Tax (5%):", "Rs." + (int) calculateTax()));
        r.append("============================================\n");
        r.append(String.format("%-27s %9s\n", "GRAND TOTAL:", "Rs." + (int) calculateGrandTotal()));
        r.append("============================================\n");
        r.append("Status  : ").append(orderStatus).append("\n");
        r.append(calculateShipping() == 0 ? "✓ FREE Shipping Applied!\n" : "");
        r.append("  Thank you for shopping with ShopZone!  \n");
        r.append("============================================\n");
        return r.toString();
    }

    public ArrayList<Product> getCartItems() { return cartItems; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String n) { this.customerName = n; }
    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String e) { this.customerEmail = e; }
    public int getCartSize() { return cartItems.size(); }
    public int getOrderNumber() { return orderNumber; }
    public void setOrderStatus(String s) { this.orderStatus = s; }
}
