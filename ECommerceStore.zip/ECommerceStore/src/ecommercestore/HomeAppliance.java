package ecommercestore;

public class HomeAppliance extends Product {
    //attributes of homeappliance

    private String brand;
    private String powerRating;

    //constructor

    public HomeAppliance(String productId, String productName, double price, int stock, String brand, String powerRating) {
        super(productId, productName, price, stock);
        this.brand = brand;
        this.powerRating = powerRating;
    }

    //method override from base product class to child class

    @Override
    public String getCategory() { return "Home & Living"; }

    @Override
    public String getDescription() {
        return brand + " | " + powerRating + " | " + getProductName();
    }

    @Override
    public double calculateDiscount() { return getPrice() * 0.08; }

    public String getBrand() { return brand; }
    public String getPowerRating() { return powerRating; }
}
