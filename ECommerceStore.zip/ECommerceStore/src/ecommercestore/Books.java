package ecommercestore;

public class Books extends Product {
    private String author;
    private String genre;
    private int pages;

    public Books(String id, String name, double price, int stock, String brand, String author, String genre, int pages) {
        super(id, name, price, stock, brand);
        this.author = author; this.genre = genre; this.pages = pages;
    }

    @Override public String getCategory() { return "Books"; }

    @Override
    public String getProductDetails() {
        return getProductName() + " | Author: " + author + " | Genre: " + genre +
               " | Pages: " + pages + " | Price: Rs." + (int) getPrice();
    }

    @Override public double calculateDiscount() { return 50; }

    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public int getPages() { return pages; }
}
