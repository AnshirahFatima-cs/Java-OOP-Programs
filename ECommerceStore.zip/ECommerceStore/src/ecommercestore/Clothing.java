package ecommercestore;

public class Clothing extends Product {
    private String size;
    private String color;
    private String material;

    public Clothing(String id, String name, double price, int stock, String brand, String size, String color, String material) {
        super(id, name, price, stock, brand);
        this.size = size; this.color = color; this.material = material;
    }

    @Override public String getCategory() { return "Clothing"; }

    @Override
    public String getProductDetails() {
        return getProductName() + " | Brand: " + getBrand() + " | Size: " + size +
               " | Color: " + color + " | Material: " + material + " | Price: Rs." + (int) getPrice();
    }

    @Override
    public double calculateDiscount() {
        return size.equals("XL") || size.equals("XXL") ? getPrice() * 0.15 : getPrice() * 0.08;
    }

    public String getSize() { return size; }
    public String getColor() { return color; }
    public String getMaterial() { return material; }
}
