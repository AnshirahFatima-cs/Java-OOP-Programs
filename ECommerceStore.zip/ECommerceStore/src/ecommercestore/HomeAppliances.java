package ecommercestore;

public class HomeAppliances extends Product {
    private String powerRating;
    private String type;

    public HomeAppliances(String id, String name, double price, int stock, String brand, String powerRating, String type) {
        super(id, name, price, stock, brand);
        this.powerRating = powerRating; this.type = type;
    }

    @Override public String getCategory() { return "Home Appliances"; }

    @Override
    public String getProductDetails() {
        return getProductName() + " | Brand: " + getBrand() + " | Type: " + type +
               " | Power: " + powerRating + " | Price: Rs." + (int) getPrice();
    }

    @Override public double calculateDiscount() { return getPrice() * 0.12; }

    public String getPowerRating() { return powerRating; }
    public String getType() { return type; }
}
