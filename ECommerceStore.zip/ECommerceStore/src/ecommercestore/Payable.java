package ecommercestore;

/**
 * Payable Interface
 * Demonstrates INTERFACE concept from OOP
 * All payment methods must implement this interface
 * @author BSCS Student
 */
public interface Payable {
    
    // Method to process payment
    boolean processPayment(double amount);
    
    // Method to get payment method name
    String getPaymentMethod();
    
    // Method to generate payment receipt
    String generatePaymentReceipt(double amount);
}
