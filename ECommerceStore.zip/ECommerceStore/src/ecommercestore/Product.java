package ecommercestore;

/**
 * Abstract Product Class
 * Demonstrates ABSTRACTION and ENCAPSULATION concepts
 * Base class for all product types
 */
public abstract class Product {
    private String productId;
    private String productName;
    private double price;
    private int stockQuantity;
    private String brand;
    private boolean isAvailable;

    public Product(String productId, String productName, double price,
                   int stockQuantity, String brand) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.brand = brand;
        this.isAvailable = stockQuantity > 0;
    }

    public abstract String getCategory();
    public abstract String getProductDetails();
    public abstract double calculateDiscount();

    public double getFinalPrice() { return price - calculateDiscount(); }
    public double getFinalPrice(int quantity) { return (price - calculateDiscount()) * quantity; }
    public double getFinalPrice(int quantity, double couponDiscount) {
        double total = (price - calculateDiscount()) * quantity;
        return total - (total * couponDiscount / 100);
    }

    public boolean reduceStock(int quantity) {
        if (stockQuantity >= quantity) {
            stockQuantity -= quantity;
            isAvailable = stockQuantity > 0;
            return true;
        }
        return false;
    }

    public String getProductId() { return productId; }
    public String getProductName() { return productName; }
    public void setProductName(String name) { this.productName = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) { if (price > 0) this.price = price; }
    public int getStockQuantity() { return stockQuantity; }
    public void setStockQuantity(int qty) { if (qty >= 0) { this.stockQuantity = qty; this.isAvailable = qty > 0; } }
    public String getBrand() { return brand; }
    public boolean isAvailable() { return isAvailable; }

    @Override
    public String toString() { return productName + " - Rs." + (int) price; }
}
