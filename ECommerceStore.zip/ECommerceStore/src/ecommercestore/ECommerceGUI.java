package ecommercestore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * Main GUI Class for ShopEase E-Commerce System
 * Demonstrates complete OOP implementation with Java Swing
 * @author BSCS Student - Section B
 */
public class ECommerceGUI extends JFrame {

    // Color Theme
    private final Color PRIMARY   = new Color(63, 81, 181);
    private final Color SECONDARY = new Color(233, 30, 99);
    private final Color SUCCESS   = new Color(76, 175, 80);
    private final Color WARNING   = new Color(255, 152, 0);
    private final Color DARK      = new Color(25, 25, 35);
    private final Color CARD_BG   = new Color(35, 35, 50);
    private final Color LIGHT_BG  = new Color(45, 45, 65);
    private final Color WHITE     = Color.WHITE;
    private final Color GOLD      = new Color(255, 215, 0);

    // Data
    private ArrayList<Product> allProducts;
    private ShoppingCart cart;
    private Payable selectedPayment;

    // GUI Components
    private JTextField txtCustomerName;
    private JComboBox<String> cmbCategory;
    private JList<String> lstProducts;
    private DefaultListModel<String> productModel;
    private JTable tblCart;
    private DefaultTableModel cartModel;
    private JTextArea txtInvoice;
    private JTextArea txtProductDetail;
    private JLabel lblTotal;
    private JLabel lblStatus;
    private JLabel lblCartCount;
    private JSpinner spinQty;
    private JComboBox<String> cmbPayment;

    public ECommerceGUI() {
        initProducts();
        buildGUI();
    }

    // ===== INITIALIZE PRODUCTS =====
    private void initProducts() {
        allProducts = new ArrayList<>();

        // Electronics
        allProducts.add(new Electronics("E001", "Samsung Galaxy A54", 89999, 15, "Samsung", 24, "6.4\" AMOLED, 128GB, 8GB RAM"));
        allProducts.add(new Electronics("E002", "HP Laptop 15s", 129999, 8, "HP", 12, "Core i5, 512GB SSD, 8GB RAM, 15.6\""));
        allProducts.add(new Electronics("E003", "Sony WH-1000XM4 Headphones", 45999, 20, "Sony", 12, "Noise Cancelling, 30hr battery"));
        allProducts.add(new Electronics("E004", "Apple iPad 10th Gen", 119999, 10, "Apple", 24, "10.9\", A14 Bionic, 64GB, WiFi"));
        allProducts.add(new Electronics("E005", "Canon DSLR EOS 1500D", 89999, 5, "Canon", 12, "24.1MP, 18-55mm lens, Full HD video"));

        // Clothing
        allProducts.add(new Clothing("C001", "Men's Casual Shirt", 2499, 50, "Bonanza", "M", "Blue", "Cotton"));
        allProducts.add(new Clothing("C002", "Women's Lawn Suit", 3999, 35, "Gul Ahmed", "S", "Multicolor", "Lawn"));
        allProducts.add(new Clothing("C003", "Kids School Uniform", 1999, 60, "Outfitters", "XS", "White/Blue", "Polyester"));
        allProducts.add(new Clothing("C004", "Men's Denim Jeans", 3499, 40, "Levi's", "XL", "Dark Blue", "Denim"));
        allProducts.add(new Clothing("C005", "Women's Abaya", 5999, 25, "Khaadi", "XXL", "Black", "Chiffon"));

        // Books
        allProducts.add(new Books("B001", "Java: How to Program", 1999, 30, "Pearson", "Deitel", "Programming", 1000));
        allProducts.add(new Books("B002", "Introduction to Algorithms", 2499, 20, "MIT Press", "CLRS", "Computer Science", 1312));
        allProducts.add(new Books("B003", "Clean Code", 1799, 25, "Prentice Hall", "Robert Martin", "Programming", 464));
        allProducts.add(new Books("B004", "Pakistan Studies", 599, 100, "Oxford", "Various", "Education", 350));
        allProducts.add(new Books("B005", "Data Structures in Java", 1499, 40, "Wiley", "Goodrich", "Programming", 736));

        // Home Appliances
        allProducts.add(new HomeAppliances("H001", "Dawlance Refrigerator 16 CFT", 79999, 8, "Dawlance", "150W", "Double Door"));
        allProducts.add(new HomeAppliances("H002", "Haier Washing Machine 8Kg", 59999, 12, "Haier", "500W", "Front Load"));
        allProducts.add(new HomeAppliances("H003", "Gree Split AC 1.5 Ton", 89999, 6, "Gree", "1800W", "Inverter AC"));
        allProducts.add(new HomeAppliances("H004", "Anex Blender 700W", 3999, 30, "Anex", "700W", "Kitchen"));
        allProducts.add(new HomeAppliances("H005", "Philips Air Fryer", 18999, 15, "Philips", "1400W", "Kitchen"));
    }

    // ===== BUILD GUI =====
    private void buildGUI() {
        setTitle("🛍️ ShopEase - E-Commerce Shopping Store");
        setSize(1150, 780);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));
        getContentPane().setBackground(DARK);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildMainPanel(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ===== HEADER =====
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        // Logo area
        JPanel logoPanel = new JPanel(new GridLayout(2, 1));
        logoPanel.setBackground(PRIMARY);

        JLabel logo = new JLabel("🛍️  SHOPEASE");
        logo.setFont(new Font("Arial", Font.BOLD, 26));
        logo.setForeground(WHITE);

        JLabel tagline = new JLabel("Pakistan's Favorite Online Store | Electronics | Clothing | Books | Home");
        tagline.setFont(new Font("Arial", Font.ITALIC, 12));
        tagline.setForeground(new Color(200, 210, 255));

        logoPanel.add(logo);
        logoPanel.add(tagline);

        // Customer panel
        JPanel custPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        custPanel.setBackground(PRIMARY);

        JLabel lblName = new JLabel("👤 Customer:");
        lblName.setForeground(WHITE);
        lblName.setFont(new Font("Arial", Font.BOLD, 13));

        txtCustomerName = new JTextField("Enter your name", 16);
        txtCustomerName.setFont(new Font("Arial", Font.PLAIN, 13));
        txtCustomerName.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (txtCustomerName.getText().equals("Enter your name"))
                    txtCustomerName.setText("");
            }
        });

        JButton btnStart = makeButton("🚀 Start Shopping", SUCCESS);
        btnStart.addActionListener(e -> startShopping());

        lblCartCount = new JLabel("🛒 Cart: 0 items");
        lblCartCount.setForeground(GOLD);
        lblCartCount.setFont(new Font("Arial", Font.BOLD, 13));

        custPanel.add(lblName);
        custPanel.add(txtCustomerName);
        custPanel.add(btnStart);
        custPanel.add(lblCartCount);

        header.add(logoPanel, BorderLayout.WEST);
        header.add(custPanel, BorderLayout.EAST);
        return header;
    }

    // ===== MAIN PANEL =====
    private JPanel buildMainPanel() {
        JPanel main = new JPanel(new GridLayout(1, 3, 5, 5));
        main.setBackground(DARK);
        main.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        main.add(buildProductPanel());
        main.add(buildCartPanel());
        main.add(buildCheckoutPanel());
        return main;
    }

    // ===== PRODUCT PANEL =====
    private JPanel buildProductPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(PRIMARY, 2),
            "  📦 PRODUCT CATALOG  ", 0, 0,
            new Font("Arial", Font.BOLD, 13), PRIMARY));

        // Search and filter
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBackground(CARD_BG);
        topPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterRow.setBackground(CARD_BG);

        JLabel lblCat = new JLabel("Category: ");
        lblCat.setForeground(WHITE);
        lblCat.setFont(new Font("Arial", Font.BOLD, 12));

        String[] cats = {"All", "Electronics", "Clothing", "Books", "Home Appliances"};
        cmbCategory = new JComboBox<>(cats);
        cmbCategory.setBackground(LIGHT_BG);
        cmbCategory.setForeground(WHITE);
        cmbCategory.setFont(new Font("Arial", Font.PLAIN, 12));
        cmbCategory.addActionListener(e -> filterProducts());

        filterRow.add(lblCat);
        filterRow.add(cmbCategory);
        topPanel.add(filterRow, BorderLayout.NORTH);

        // Product list
        productModel = new DefaultListModel<>();
        lstProducts = new JList<>(productModel);
        lstProducts.setBackground(LIGHT_BG);
        lstProducts.setForeground(WHITE);
        lstProducts.setFont(new Font("Arial", Font.PLAIN, 12));
        lstProducts.setSelectionBackground(new Color(100, 120, 220));
        lstProducts.setSelectionForeground(WHITE);
        lstProducts.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        lstProducts.addListSelectionListener(e -> showProductDetail());

        loadProducts("All");
        JScrollPane scrollP = new JScrollPane(lstProducts);
        scrollP.setBorder(BorderFactory.createEmptyBorder());

        // Product detail area
        txtProductDetail = new JTextArea(4, 20);
        txtProductDetail.setBackground(new Color(30, 30, 45));
        txtProductDetail.setForeground(new Color(180, 200, 255));
        txtProductDetail.setFont(new Font("Arial", Font.PLAIN, 11));
        txtProductDetail.setEditable(false);
        txtProductDetail.setLineWrap(true);
        txtProductDetail.setWrapStyleWord(true);
        txtProductDetail.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        // Add to cart section
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        addPanel.setBackground(CARD_BG);

        JLabel lblQty = new JLabel("Qty:");
        lblQty.setForeground(WHITE);
        lblQty.setFont(new Font("Arial", Font.BOLD, 12));

        spinQty = new JSpinner(new SpinnerNumberModel(1, 1, 50, 1));
        spinQty.setPreferredSize(new Dimension(65, 28));

        JButton btnAdd = makeButton("🛒 Add to Cart", SUCCESS);
        btnAdd.addActionListener(e -> addToCart());

        addPanel.add(lblQty);
        addPanel.add(spinQty);
        addPanel.add(btnAdd);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(CARD_BG);
        bottomPanel.add(new JScrollPane(txtProductDetail), BorderLayout.CENTER);
        bottomPanel.add(addPanel, BorderLayout.SOUTH);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollP, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ===== CART PANEL =====
    private JPanel buildCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(SECONDARY, 2),
            "  🛒 SHOPPING CART  ", 0, 0,
            new Font("Arial", Font.BOLD, 13), SECONDARY));

        String[] cols = {"Product", "Category", "Qty", "Unit Price", "Total"};
        cartModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tblCart = new JTable(cartModel);
        tblCart.setBackground(LIGHT_BG);
        tblCart.setForeground(WHITE);
        tblCart.setFont(new Font("Arial", Font.PLAIN, 12));
        tblCart.setRowHeight(28);
        tblCart.setGridColor(new Color(70, 70, 100));
        tblCart.getTableHeader().setBackground(SECONDARY);
        tblCart.getTableHeader().setForeground(WHITE);
        tblCart.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tblCart.setSelectionBackground(new Color(200, 50, 100));

        tblCart.getColumnModel().getColumn(0).setPreferredWidth(130);
        tblCart.getColumnModel().getColumn(1).setPreferredWidth(80);
        tblCart.getColumnModel().getColumn(2).setPreferredWidth(40);
        tblCart.getColumnModel().getColumn(3).setPreferredWidth(70);
        tblCart.getColumnModel().getColumn(4).setPreferredWidth(70);

        JScrollPane scrollC = new JScrollPane(tblCart);
        scrollC.getViewport().setBackground(LIGHT_BG);
        scrollC.setBorder(BorderFactory.createEmptyBorder());

        // Total label
        lblTotal = new JLabel("Grand Total: Rs. 0");
        lblTotal.setForeground(GOLD);
        lblTotal.setFont(new Font("Arial", Font.BOLD, 15));
        lblTotal.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        lblTotal.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel infoPanel = new JPanel(new GridLayout(3, 1));
        infoPanel.setBackground(CARD_BG);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 0, 10));

        JLabel lblShip = new JLabel("🚚 FREE Shipping on orders above Rs.5000");
        lblShip.setForeground(SUCCESS);
        lblShip.setFont(new Font("Arial", Font.ITALIC, 11));

        JLabel lblTax = new JLabel("📋 17% GST included in total");
        lblTax.setForeground(new Color(180, 180, 180));
        lblTax.setFont(new Font("Arial", Font.ITALIC, 11));

        infoPanel.add(lblTotal);
        infoPanel.add(lblShip);
        infoPanel.add(lblTax);

        // Cart buttons
        JPanel btnPanel = new JPanel(new GridLayout(1, 3, 5, 5));
        btnPanel.setBackground(CARD_BG);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JButton btnRemove = makeButton("🗑 Remove", new Color(244, 67, 54));
        btnRemove.addActionListener(e -> removeFromCart());

        JButton btnClear = makeButton("🔄 Clear", new Color(96, 125, 139));
        btnClear.addActionListener(e -> clearCart());

        JButton btnCheckout = makeButton("💳 Checkout", PRIMARY);
        btnCheckout.addActionListener(e -> proceedCheckout());

        btnPanel.add(btnRemove);
        btnPanel.add(btnClear);
        btnPanel.add(btnCheckout);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(CARD_BG);
        bottomPanel.add(infoPanel, BorderLayout.CENTER);
        bottomPanel.add(btnPanel, BorderLayout.SOUTH);

        panel.add(scrollC, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ===== CHECKOUT PANEL =====
    private JPanel buildCheckoutPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(SUCCESS, 2),
            "  💳 CHECKOUT & INVOICE  ", 0, 0,
            new Font("Arial", Font.BOLD, 13), SUCCESS));

        // Payment section
        JPanel payPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        payPanel.setBackground(CARD_BG);
        payPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel lblPay = new JLabel("💳 Select Payment Method:");
        lblPay.setForeground(WHITE);
        lblPay.setFont(new Font("Arial", Font.BOLD, 12));

        String[] payments = {"Cash on Delivery", "Credit/Debit Card", "EasyPaisa"};
        cmbPayment = new JComboBox<>(payments);
        cmbPayment.setBackground(LIGHT_BG);
        cmbPayment.setForeground(WHITE);
        cmbPayment.setFont(new Font("Arial", Font.PLAIN, 12));

        JButton btnPlaceOrder = makeButton("✅ PLACE ORDER", SUCCESS);
        btnPlaceOrder.setFont(new Font("Arial", Font.BOLD, 14));
        btnPlaceOrder.addActionListener(e -> placeOrder());

        payPanel.add(lblPay);
        payPanel.add(cmbPayment);
        payPanel.add(btnPlaceOrder);

        // Invoice area
        txtInvoice = new JTextArea();
        txtInvoice.setBackground(new Color(15, 15, 25));
        txtInvoice.setForeground(new Color(0, 255, 128));
        txtInvoice.setFont(new Font("Monospaced", Font.PLAIN, 11));
        txtInvoice.setEditable(false);
        txtInvoice.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtInvoice.setText("\n\n\n   Welcome to ShopEase!\n\n" +
                          "   Step 1: Enter your name\n" +
                          "   Step 2: Click Start Shopping\n" +
                          "   Step 3: Add items to cart\n" +
                          "   Step 4: Select payment method\n" +
                          "   Step 5: Place your order!\n\n" +
                          "   Your invoice will appear here.");

        JScrollPane scrollI = new JScrollPane(txtInvoice);
        scrollI.setBorder(BorderFactory.createEmptyBorder());

        JButton btnNew = makeButton("🆕 New Order", new Color(33, 150, 243));
        btnNew.addActionListener(e -> newOrder());

        panel.add(payPanel, BorderLayout.NORTH);
        panel.add(scrollI, BorderLayout.CENTER);
        panel.add(btnNew, BorderLayout.SOUTH);
        return panel;
    }

    // ===== STATUS BAR =====
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(20, 20, 30));
        bar.setBorder(BorderFactory.createEmptyBorder(4, 15, 4, 15));

        lblStatus = new JLabel("👋 Welcome to ShopEase! Enter your name and click Start Shopping.");
        lblStatus.setForeground(new Color(160, 160, 180));
        lblStatus.setFont(new Font("Arial", Font.ITALIC, 12));

        JLabel lblOOP = new JLabel("OOP Concepts: Abstraction | Encapsulation | Inheritance | Polymorphism | Interface | Composition");
        lblOOP.setForeground(new Color(80, 80, 100));
        lblOOP.setFont(new Font("Arial", Font.PLAIN, 10));

        bar.add(lblStatus, BorderLayout.WEST);
        bar.add(lblOOP, BorderLayout.EAST);
        return bar;
    }

    // ===== HELPER METHODS =====
    private JButton makeButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(color.brighter()); }
            public void mouseExited(MouseEvent e) { btn.setBackground(color); }
        });
        return btn;
    }

    private void loadProducts(String category) {
        productModel.clear();
        for (Product p : allProducts) {
            if (category.equals("All") || p.getCategory().equals(category)) {
                String disc = p.calculateDiscount() > 0 ?
                    " [SALE! Rs." + (int) p.calculateDiscount() + " OFF]" : "";
                productModel.addElement(p.getProductName() + "  —  Rs." + (int) p.getFinalPrice() + disc);
            }
        }
    }

    private void filterProducts() {
        String cat = (String) cmbCategory.getSelectedItem();
        loadProducts(cat);
        txtProductDetail.setText("");
    }

    private Product getSelectedProduct() {
        int idx = lstProducts.getSelectedIndex();
        if (idx < 0) return null;
        String cat = (String) cmbCategory.getSelectedItem();
        int count = 0;
        for (Product p : allProducts) {
            if (cat.equals("All") || p.getCategory().equals(cat)) {
                if (count == idx) return p;
                count++;
            }
        }
        return null;
    }

    private void showProductDetail() {
        Product p = getSelectedProduct();
        if (p != null) {
            txtProductDetail.setText(
                "📦 " + p.getProductDetails() + "\n\n" +
                "💰 Original Price: Rs." + (int) p.getPrice() + "\n" +
                "🏷️ Discount: Rs." + (int) p.calculateDiscount() + "\n" +
                "✅ Final Price: Rs." + (int) p.getFinalPrice() + "\n" +
                "📊 Stock Available: " + p.getStockQuantity() + " units"
            );
        }
    }

    private void startShopping() {
        String name = txtCustomerName.getText().trim();
        if (name.isEmpty() || name.equals("Enter your name")) {
            JOptionPane.showMessageDialog(this, "Please enter your name first!", "Name Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        cart = new ShoppingCart(name);
        lblStatus.setText("✅ Shopping started for: " + name + " | Browse products and add to cart!");
        txtInvoice.setText("\n\n  Shopping started for: " + name + "\n\n  Add items to cart and place order!");
        updateTotal();
    }

    private void addToCart() {
        if (cart == null) {
            JOptionPane.showMessageDialog(this, "Please start shopping first!", "Start Shopping", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Product p = getSelectedProduct();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Please select a product!", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!p.isAvailable()) {
            JOptionPane.showMessageDialog(this, "Sorry! This product is out of stock!", "Out of Stock", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int qty = (int) spinQty.getValue();
        if (qty > p.getStockQuantity()) {
            JOptionPane.showMessageDialog(this, "Only " + p.getStockQuantity() + " units available!", "Insufficient Stock", JOptionPane.WARNING_MESSAGE);
            return;
        }

        cart.addItem(p, qty);

        // Add to table
        cartModel.addRow(new Object[]{
            p.getProductName(),
            p.getCategory(),
            qty,
            "Rs." + (int) p.getFinalPrice(),
            "Rs." + (int) p.getFinalPrice(qty)
        });

        updateTotal();
        updateCartCount();
        lblStatus.setText("✅ Added: " + p.getProductName() + " x" + qty + " | Total: Rs." + (int) cart.calculateGrandTotal());
    }

    private void removeFromCart() {
        if (cart == null || cart.getCartSize() == 0) return;
        int row = tblCart.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item to remove!", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String name = (String) cartModel.getValueAt(row, 0);
        cart.removeItem(row);
        cartModel.removeRow(row);
        updateTotal();
        updateCartCount();
        lblStatus.setText("🗑 Removed: " + name);
    }

    private void clearCart() {
        if (cart == null || cart.getCartSize() == 0) return;
        int c = JOptionPane.showConfirmDialog(this, "Clear all items from cart?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) {
            cart.clearCart();
            cartModel.setRowCount(0);
            updateTotal();
            updateCartCount();
            lblStatus.setText("🔄 Cart cleared.");
        }
    }

    private void proceedCheckout() {
        if (cart == null || cart.getCartSize() == 0) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!", "Empty Cart", JOptionPane.WARNING_MESSAGE);
            return;
        }
        lblStatus.setText("💳 Select payment method and click PLACE ORDER to complete purchase!");
        JOptionPane.showMessageDialog(this,
            "Your cart has " + cart.getCartSize() + " items.\n" +
            "Grand Total: Rs." + (int) cart.calculateGrandTotal() + "\n\n" +
            "Please select payment method and place order.",
            "Proceed to Checkout", JOptionPane.INFORMATION_MESSAGE);
    }

    private void placeOrder() {
        if (cart == null || cart.getCartSize() == 0) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!", "Empty Cart", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String payMethod = (String) cmbPayment.getSelectedItem();

        // Polymorphism - different payment methods
        if (payMethod.equals("Cash on Delivery")) {
            selectedPayment = new CashPayment("CS001");
        } else if (payMethod.equals("Credit/Debit Card")) {
            selectedPayment = new CardPayment("1234567890123456", cart.getCustomerId());
        } else {
            selectedPayment = new EasyPaisaPayment("03001234567");
        }

        selectedPayment.processPayment(cart.calculateGrandTotal());
        txtInvoice.setText(cart.generateInvoice(selectedPayment.getPaymentMethod()) +
                          "\n" + selectedPayment.generatePaymentReceipt(cart.calculateGrandTotal()));

        lblStatus.setText("🎉 Order #" + cart.getOrderId() + " placed successfully! Thank you, " + cart.getCustomerId() + "!");

        JOptionPane.showMessageDialog(this,
            "🎉 Order Placed Successfully!\n" +
            "Order ID: #" + cart.getOrderId() + "\n" +
            "Payment: " + selectedPayment.getPaymentMethod() + "\n" +
            "Total: Rs." + (int) cart.calculateGrandTotal() + "\n\n" +
            "Thank you for shopping at ShopEase!",
            "Order Confirmed! ✅", JOptionPane.INFORMATION_MESSAGE);
    }

    private void newOrder() {
        int c = JOptionPane.showConfirmDialog(this, "Start a new order? Current order will be cleared.", "New Order", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) {
            cart = null;
            cartModel.setRowCount(0);
            txtCustomerName.setText("Enter your name");
            txtInvoice.setText("\n\n\n   New session ready!\n   Enter your name to start shopping.");
            lblTotal.setText("Grand Total: Rs. 0");
            lblCartCount.setText("🛒 Cart: 0 items");
            lblStatus.setText("👋 Welcome back! Enter your name to start a new order.");
        }
    }

    private void updateTotal() {
        if (cart != null) {
            lblTotal.setText("Grand Total (incl. tax+shipping): Rs. " + (int) cart.calculateGrandTotal());
        }
    }

    private void updateCartCount() {
        if (cart != null) {
            lblCartCount.setText("🛒 Cart: " + cart.getCartSize() + " items");
        }
    }

    // ===== MAIN METHOD =====
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new ECommerceGUI());
    }
}
