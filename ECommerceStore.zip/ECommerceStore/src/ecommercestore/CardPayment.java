package ecommercestore;

public class CardPayment implements Payable {
    private String cardNumber;
    private String cardHolder;

    public CardPayment(String cardNumber, String cardHolder) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }

    @Override
    public boolean processPayment(double amount) {
        System.out.println("Card payment of Rs." + (int) amount + " processed.");
        return true;
    }

    @Override public String getPaymentMethod() { return "Credit/Debit Card"; }

    @Override
    public String generatePaymentReceipt(double amount) {
        String masked = "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
        return "CARD PAYMENT\nCard: " + masked + "\nHolder: " + cardHolder +
               "\nAmount: Rs." + (int) amount + "\nStatus: Approved";
    }
}
