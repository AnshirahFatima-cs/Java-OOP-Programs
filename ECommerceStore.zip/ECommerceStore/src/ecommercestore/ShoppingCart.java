package ecommercestore;

import java.util.ArrayList;

/**
 * ShoppingCart - COMPOSITION (Cart HAS-A list of CartItems)
 */
public class ShoppingCart {
    private ArrayList<CartItem> items;
    private String customerId;
    private static int orderCount = 0;
    private int orderId;

    public ShoppingCart(String customerId) {
        this.customerId = customerId;
        this.items = new ArrayList<>();
        orderCount++;
        this.orderId = orderCount;
    }

    public void addItem(Product product, int quantity) {
        for (CartItem item : items) {
            if (item.getProduct().getProductId().equals(product.getProductId())) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        items.add(new CartItem(product, quantity));
    }

    public void removeItem(int index) {
        if (index >= 0 && index < items.size()) items.remove(index);
    }

    public void clearCart() { items.clear(); }

    public double calculateSubTotal() {
        double total = 0;
        for (CartItem item : items) total += item.getItemTotal();
        return total;
    }

    public double calculateTax() { return calculateSubTotal() * 0.17; }
    public double calculateShipping() { return calculateSubTotal() > 5000 ? 0 : 200; }
    public double calculateGrandTotal() { return calculateSubTotal() + calculateTax() + calculateShipping(); }

    public String generateInvoice(String paymentMethod) {
        StringBuilder inv = new StringBuilder();
        inv.append("========================================\n");
        inv.append("       SHOPEASE - ORDER INVOICE        \n");
        inv.append("========================================\n");
        inv.append("Order ID   : #").append(orderId).append("\n");
        inv.append("Customer   : ").append(customerId).append("\n");
        inv.append("Payment    : ").append(paymentMethod).append("\n");
        inv.append("----------------------------------------\n");
        inv.append(String.format("%-22s %5s %8s\n", "Product", "Qty", "Total"));
        inv.append("----------------------------------------\n");
        for (CartItem item : items) {
            inv.append(String.format("%-22s %5d %8s\n",
                item.getProduct().getProductName(),
                item.getQuantity(),
                "Rs." + (int) item.getItemTotal()));
        }
        inv.append("----------------------------------------\n");
        inv.append(String.format("%-28s %8s\n", "Subtotal:", "Rs." + (int) calculateSubTotal()));
        inv.append(String.format("%-28s %8s\n", "Tax (17% GST):", "Rs." + (int) calculateTax()));
        inv.append(String.format("%-28s %8s\n", "Shipping:", calculateShipping() == 0 ? "FREE" : "Rs.200"));
        inv.append("========================================\n");
        inv.append(String.format("%-28s %8s\n", "GRAND TOTAL:", "Rs." + (int) calculateGrandTotal()));
        inv.append("========================================\n");
        inv.append("  Thank you for shopping at ShopEase!  \n");
        inv.append("========================================\n");
        return inv.toString();
    }

    public ArrayList<CartItem> getItems() { return items; }
    public int getCartSize() { return items.size(); }
    public String getCustomerId() { return customerId; }
    public int getOrderId() { return orderId; }
}
