package ecommercestore;

/**
 * CashPayment - implements Payable INTERFACE
 * Demonstrates INTERFACE implementation and POLYMORPHISM
 */
public class CashPayment implements Payable {
    private String cashierId;

    public CashPayment(String cashierId) { this.cashierId = cashierId; }

    @Override
    public boolean processPayment(double amount) {
        System.out.println("Cash payment of Rs." + (int) amount + " processed.");
        return true;
    }

    @Override public String getPaymentMethod() { return "Cash on Delivery"; }

    @Override
    public String generatePaymentReceipt(double amount) {
        return "CASH PAYMENT\nAmount: Rs." + (int) amount + "\nStatus: Confirmed\nCashier: " + cashierId;
    }
}
