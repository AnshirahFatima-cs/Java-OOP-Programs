package ecommercestore;

/**
 * Electronics - extends Product (INHERITANCE)
 */
public class Electronics extends Product {
    private int warrantyMonths;
    private String specifications;

    public Electronics(String id, String name, double price, int stock, String brand, int warranty, String specs) {
        super(id, name, price, stock, brand);
        this.warrantyMonths = warranty;
        this.specifications = specs;
    }

    @Override public String getCategory() { return "Electronics"; }

    @Override
    public String getProductDetails() {
        return getProductName() + " | Brand: " + getBrand() + " | Warranty: " + warrantyMonths +
               " months | Specs: " + specifications + " | Price: Rs." + (int) getPrice();
    }

    @Override
    public double calculateDiscount() {
        return warrantyMonths >= 12 ? getPrice() * 0.10 : getPrice() * 0.05;
    }

    public int getWarrantyMonths() { return warrantyMonths; }
    public String getSpecifications() { return specifications; }
}
