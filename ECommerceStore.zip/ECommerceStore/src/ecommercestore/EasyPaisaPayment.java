package ecommercestore;

public class EasyPaisaPayment implements Payable {
    private String mobileNumber;

    public EasyPaisaPayment(String mobileNumber) { this.mobileNumber = mobileNumber; }

    @Override
    public boolean processPayment(double amount) {
        System.out.println("EasyPaisa payment of Rs." + (int) amount + " sent to " + mobileNumber);
        return true;
    }

    @Override public String getPaymentMethod() { return "EasyPaisa"; }

    @Override
    public String generatePaymentReceipt(double amount) {
        return "EASYPAISA PAYMENT\nMobile: " + mobileNumber +
               "\nAmount: Rs." + (int) amount + "\nStatus: Transferred Successfully";
    }
}
